package com.RC_Plus;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Properties;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ConvertExcelToJSON {

	/*public static void main(String[] args) {
		// JsonObject p =
		// convertFileToJSON("C:\\WorkSpace\\RC_PLUS\\beta_version\\findWebElement.json");
		// System.out.println(p.get("Remit Ccy"));
		// getExcelAsJsonObject();
		//getExcelAsJsonObject();
	}*/

	JsonObject getJSON(String fileName) {

		// Read from File to String
		JsonObject jsonObject = new JsonObject();

		try {
			JsonParser parser = new JsonParser();
			JsonElement jsonElement = parser.parse(new FileReader(fileName));
			jsonObject = jsonElement.getAsJsonObject();
		} catch (FileNotFoundException e) {
			System.out.println("file not found");

		}
		return jsonObject;
	}

	static JsonObject[] getExcelAsJsonObject(String absolutePath) throws IOException {
		
		
			FileInputStream fileInputStream = new FileInputStream(new File(absolutePath));
			XSSFWorkbook xssfWorkbook = new XSSFWorkbook(fileInputStream);
			int sheetCount = xssfWorkbook.getNumberOfSheets();
			XSSFSheet xssfSheet;
			JsonObject[] jsonOfExcel= new JsonObject[sheetCount];
			DataFormatter dataFormatter = new DataFormatter();
			
			for(int sheetIndex = 0;sheetIndex<sheetCount;sheetIndex++){

				xssfSheet = xssfWorkbook.getSheetAt(sheetIndex);
				JsonObject jsonObject = new JsonObject();
				Set<String> header = new LinkedHashSet<String>();
				Row row = null;
				Cell cell = null;

				// picks only header
				Iterator<Row> headerRow = xssfSheet.rowIterator();

				do {
					row = headerRow.next();
					Iterator<Cell> headerCell = row.cellIterator();
					headerCell.next();
					while (headerCell.hasNext()) {
						cell = headerCell.next();
						if (cell.getCellType() == Cell.CELL_TYPE_STRING)
							header.add(cell.getStringCellValue());
					}
				} while (false);
				//System.out.println("Headers : " + header);
				Object[] headerArray = header.toArray();
				
				
				//picks data
				for(int rowNumber = 1;rowNumber<=xssfSheet.getLastRowNum();rowNumber++)
				{
					XSSFRow row1 = xssfSheet.getRow(rowNumber);
					XSSFCell Rno1 = row1.getCell(0);
					int Rno = (int) Rno1.getNumericCellValue();
					JsonObject innerJsonObject = new JsonObject();
					
					for(int columnNumber = 1,headerLoopingIndex=0;columnNumber<row1.getLastCellNum();columnNumber++,headerLoopingIndex++)
					{
						XSSFCell cell1 = row1.getCell(columnNumber);
						switch (cell1.getCellType())
							{

							case XSSFCell.CELL_TYPE_STRING:
								innerJsonObject.addProperty((String) headerArray[headerLoopingIndex],cell1.getStringCellValue());
								break;
								
							case XSSFCell.CELL_TYPE_NUMERIC:
								String actualValue = dataFormatter.formatCellValue(cell1);
								innerJsonObject.addProperty((String) headerArray[headerLoopingIndex], ""+ actualValue);
								break;
								
							case XSSFCell.CELL_TYPE_BLANK:break;	
					}
							
						jsonObject.add(""+Rno, innerJsonObject);
				}
					
				//System.out.println("Outer Json "+jsonObject);
			}	

				jsonOfExcel[sheetIndex] = jsonObject;
			}

			return jsonOfExcel;
	}
}