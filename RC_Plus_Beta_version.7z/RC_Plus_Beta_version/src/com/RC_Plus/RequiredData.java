package com.RC_Plus;

public interface RequiredData 
{
	//String URL="https://hklvadrap02.hk.standardchartered.com:8443/eopssec/login.jsp?fromPage=eops";
	String  URL = "https://10.20.238.173:8443/eopssec/login.jsp?fromPage=eops";
	String IEDRIVER = "C:\\software\\Selinium\\IEDriverServer.exe";	
}