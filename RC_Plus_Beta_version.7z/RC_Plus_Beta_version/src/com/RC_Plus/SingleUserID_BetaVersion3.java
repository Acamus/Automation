package com.RC_Plus;

//import java.io.File;
import java.io.IOException;
//import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
//import java.util.NoSuchElementException;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.time.StopWatch;
//import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnexpectedAlertBehaviour;
//import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;
//import com.google.common.base.Stopwatch;
//import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class SingleUserID_BetaVersion3 implements RequiredData {

	public static void main(String[] args) throws InterruptedException {
		
		System.out.println("######START########");
		
		//ConvertExcelToJSON convertExcelToJSON = new ConvertExcelToJSON();
		JsonObject loginJSONObject; // = convertExcelToJSON.getJSON("C:\\WorkSpace\\RC_PLUS\\RC_Plus_Beta_version\\Login.json");
		JsonObject dataJSONObject; //= convertExcelToJSON.getJSON("C:\\WorkSpace\\RC_PLUS\\RC_Plus_Beta_version\\Data.json");
		JsonObject[] jsonOfExcel = null;
		try 
		{
			jsonOfExcel = ConvertExcelToJSON.getExcelAsJsonObject("C:\\Users\\1553108\\Desktop\\qq.xlsx");
		}
		
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
		loginJSONObject = jsonOfExcel[0];
		dataJSONObject = jsonOfExcel[1];

		System.out.println(loginJSONObject);
		System.out.println(dataJSONObject);
		
		Set<String> dataMasterKey = getKeysOfJSONObject(dataJSONObject);
		Object[] dataMasterKeyArray = dataMasterKey.toArray();
		
		Set<String> loginMasterKey =  getKeysOfJSONObject(loginJSONObject);
		Object[] loginMasterKeyArray = loginMasterKey.toArray();
		
		System.setProperty("webdriver.ie.driver", IEDRIVER);
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, URL);
		capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
		WebDriver driver = new InternetExplorerDriver(capabilities);
		
		//implicit wait
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		//Explicit Wait
		WebDriverWait webDriverWait = new WebDriverWait(driver, 60);
		
		// Open the URL in IE browser
		driver.get(URL);
		//Thread.sleep(3000);
		
		login(driver,loginJSONObject,loginMasterKeyArray,0);
		//Thread.sleep(2000);
		
		//mouseover
		WebElement mouseOver = driver.findElement(By.xpath("//*[@id=\"tabContainer\"]/div"));
		Actions builder = new Actions(driver);
		builder.moveToElement(mouseOver).build().perform();
		
		driver.findElement(By.linkText("Inbox V2.0")).click(); 
		
		//Thread.sleep(2000);
		try
		{
		webDriverWait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("Inbox V2.0"));
		//driver.switchTo().frame("Inbox V2.0");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Inbox V2.0 frame is not available");
		}
							
				
		//search Task
		//Thread.sleep(3000);
		try
		{
			webDriverWait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("treeWidget"))));
		}
		catch(NoSuchElementException e)
		{
			System.out.println("The service for the country code is not available");
		}
		WebElement allTaskTable = driver.findElement(By.id("treeWidget"));
		List<WebElement> listOfTaskTable = allTaskTable.findElements(By.className("gwt-Label"));
		for(WebElement loopingIndex : listOfTaskTable)
		{
			if(loopingIndex.getText().contains("RapidCashPlus-"+dataJSONObject.getAsJsonObject(""+dataMasterKeyArray[0]).get("CountryCode").getAsString()))
				{
				loopingIndex.click();break;
				}
		}
		//System.out.println("Search task status "+driver.findElements(By.linkText("Search Tasks")).isEmpty());
		Thread.sleep(10000);
		
		webDriverWait.until(ExpectedConditions.visibilityOf(driver.findElement(By.linkText("Search Tasks"))));
		driver.findElement(By.linkText("Search Tasks")).click();
		
		System.out.println("No of TXn : "+dataMasterKeyArray.length);
		changeTxnLabel : for(int dataLoopingIndex=0;dataLoopingIndex<dataMasterKeyArray.length;dataLoopingIndex++) //under the inbox frame condtion the repeaeted to chnage the id		
		{
			boolean changeTxnFlag = true;
			String stepName = null;
			JsonObject jsonOfCurrentTxn = dataJSONObject.getAsJsonObject(""+dataMasterKeyArray[dataLoopingIndex]);
					
				//transaction RefNo insert and search
				driver.findElement(By.className("clear-btn")).click();
				driver.findElement(By.className("gwt-TextBox")).sendKeys(dataJSONObject.getAsJsonObject(""+dataMasterKeyArray[dataLoopingIndex]).get("TxRefNo").getAsString());
				driver.findElement(By.className("insert-btn")).click();
				//driver.findElement(By.className("search-btn")).click();
				changeTxnFlag = txnAvailabilityCheck(driver,webDriverWait,dataJSONObject,dataMasterKeyArray,dataLoopingIndex);
						
				for(;changeTxnFlag;)
				{	
					//inbox
					inbox(driver,webDriverWait, stepName, dataJSONObject, dataMasterKeyArray,dataLoopingIndex);
							
					//steps
					steps(driver,webDriverWait, dataJSONObject,jsonOfCurrentTxn, dataMasterKeyArray,dataLoopingIndex);
					
					//Thread.sleep(4000);
					
					changeTxnFlag = txnAvailabilityCheck(driver,webDriverWait,dataJSONObject,dataMasterKeyArray,dataLoopingIndex);
					if(!changeTxnFlag)break;
				}
					//if(!changeUserIdFlag)continue changeUserIDLabel; 
					if(!changeTxnFlag)
					{
					continue changeTxnLabel;
					}
			
		}
		System.out.println("*******END*******");			
	}
	
	public static Set<String> getKeysOfJSONObject(JsonObject jsonObject)
	{
		Set<String> keyss = new LinkedHashSet<String>();
		Set<Entry<String, JsonElement>> enteries = jsonObject.entrySet();
		for(Entry<String, JsonElement> enterySet : enteries)
        {
        	keyss.add(enterySet.getKey());
        }
      	return keyss;
	}

	public static void checkList(WebDriver driver) throws InterruptedException
	{
		
		WebElement tagName = driver.findElement(By.className("transactionTypeIconCont"));
		List<WebElement> buttonList  = tagName.findElements(By.tagName("button"));
		for(WebElement buttonIndex: buttonList)
		{
			String title = buttonIndex.getAttribute("title");
			if(title.equalsIgnoreCase("Checklist"))
			{
				buttonIndex.click();
				break;
			}
		}
		
		
		WebElement checkListPopUp = null;
		
		if(!driver.findElements(By.className("popuppanel")).isEmpty())
		{	
			System.out.println("Check list popup pannel is found");
			checkListPopUp = driver.findElement(By.className("popuppanel"));
			if(!driver.findElements(By.className("checkbox")).isEmpty())
			{
				System.out.println("Check list found");
				List<WebElement> checkBoxList = checkListPopUp.findElements(By.className("checkbox"));
				System.out.println("check list :"+checkBoxList.size());
				for(WebElement checkBoxIndex: checkBoxList)
				{
					String checkListID = checkBoxIndex.findElement(By.tagName("input")).getAttribute("id");
					checkBoxIndex.findElement(By.id(checkListID)).click();
				}	
				
				checkListPopUp.findElement(By.className("checklist-done-btn")).click();
			}	
		}
	}
	
	public static boolean isAlertPresent(WebDriver driver)
	{
		try
		{	
			driver.switchTo().alert().accept();
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	
	public static boolean login(final WebDriver driver, JsonObject loginJSONObject,Object[] loginMasterKeyArray,int loginLoopingIndex ) throws InterruptedException
	{
		boolean loginStatusFlag = true;
		Thread.sleep(1000);
		driver.findElement(By.className("gwt-TextBox")).clear();
		driver.findElement(By.className("gwt-TextBox")).sendKeys(loginJSONObject.getAsJsonObject(""+loginMasterKeyArray[0]).get("USERID").getAsString());
		
		driver.findElement(By.className("gwt-PasswordTextBox")).clear();
		driver.findElement(By.className("gwt-PasswordTextBox")).sendKeys(loginJSONObject.getAsJsonObject(""+loginMasterKeyArray[0]).get("PASSWORD").getAsString());

		// Click Submit button
		driver.findElement(By.className("greenbtn")).click();
		
		Thread.sleep(2000);
		
		if(!driver.findElements(By.className("saveBtn")).isEmpty())
		{	
			String title = driver.findElement(By.className("popupContent")).getAttribute("title");
			String errorMsg = driver.findElement(By.className("gwt-Label")).getText();
			System.out.println("Title : "+title+"\nMessage : "+errorMsg);
			driver.findElement(By.className("saveBtn")).click();	
		}
		
		System.out.println("Login status : "+loginStatusFlag);
		return loginStatusFlag;
	}

	public static boolean inbox(WebDriver driver,WebDriverWait webDriverWait, String stepName, JsonObject dataJSONObject, Object[] dataMasterKeyArray, int dataLoopingIndex) throws InterruptedException

	{
		boolean inboxStatusFlag = false;
		boolean dummyFlag = false;
		String taskID;
		//String stepName;
		String WIFrame = "Work Item-";
		/*Thread.sleep(40000);
		driver.findElement(By.className("search-btn")).click();
		//driver.findElement(By.className("search-btn")).click();
		Thread.sleep(5000);
*/		
		webDriverWait.until(ExpectedConditions.visibilityOf(driver.findElement(By.className("task2"))));
		WebElement table = driver.findElement(By.className("task2"));
		List<WebElement> listOfTxn = table.findElements(By.className("rs-odd"));
		for(WebElement txn :listOfTxn)
		{
			taskID = txn.findElement(By.className("gwt-Anchor")).getAttribute("title");
			WIFrame = WIFrame+taskID;
			stepName = driver.findElement(By.xpath("//*[@id=\"taskWidget\"]/div/table/tbody/tr[2]/td[3]")).getText();
			System.out.println("Work Item Frame : "+WIFrame);
			System.out.println("Step name : "+stepName);
			txn.findElement(By.tagName("a")).click();
			dummyFlag = true;
			if(dummyFlag)break;
			//txn.findElement(By.linkText(dataJSONObject.getAsJsonObject(""+dataMasterKeyArray[dataLoopingIndex]).get("TxRefNo").getAsString())).click();		
		}
			
			//while picking the txn handle the four scenarios
		//	Thread.sleep(5000);
				
			if(!driver.findElements(By.className("gwt-PopupPanel")).isEmpty())
			{
				String title = driver.findElement(By.className("popupContent")).getAttribute("title");
				System.out.println("Title is : "+title);
					
				if(title.equalsIgnoreCase("Info"))//WI picked by the same userID
				{
					inboxStatusFlag = true;
					//System.out.println(driver.findElements(By.className("saveBtn")).isEmpty());
					driver.findElement(By.xpath("/html/body/div[2]/div/table/tbody/tr[3]/td[2]/button")).click();
					//driver.findElement(By.className("saveBtn")).click();
				}
				
				else if(title.equalsIgnoreCase("Error"))//WI picked by another user or fresh WI which can be picked by other userID	
				{	
					System.out.println("if title is Error, need to check for unclok or change the user ID");
				}
			}
			
			else//fresh WI
			{		
					inboxStatusFlag = true;
			}
				
				//Switch to WI frame
				if(inboxStatusFlag)
				{
				//Thread.sleep(10000);
				driver.switchTo().defaultContent();
				webDriverWait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(WIFrame));
				//driver.switchTo().frame(WIFrame);
				}
				else //logout logic
				{
					System.out.println("Gonna Logout");
					//driver.findElement(By.className("logoutCont")).click();
					//driver.findElement(By.linkText("linkText")).click();
				}
				
				System.out.println("Inbox status flag : "+inboxStatusFlag);
				return inboxStatusFlag;
	}	

	public static void steps(WebDriver driver,WebDriverWait webDriverWait, JsonObject dataJSONObject,JsonObject jsonOfCurrentTxn ,Object[] dataMasterKeyArray, int dataLoopingIndex) throws InterruptedException
	{
		//WebElement fieldLbl = null;
		
		Select uiSelect = null;
		String	stepName = "abc";
		int stepNameValue = 0;

		if(stepName.equalsIgnoreCase("PDE Checker"))
		 stepNameValue = 1 ;
		else if(stepName.equalsIgnoreCase("Risk Raise Referral") || stepName.equalsIgnoreCase("Risk Raise Referral2"))
		 stepNameValue = 2 ;
		
		
		switch(stepNameValue)
		{
			case 1 : //keyINValues(driver, jsonOfCurrentTxn);break;
			
			case 2 : //comment codes; break; //  comment logic
			
			default : keyINValues(driver,webDriverWait, jsonOfCurrentTxn);
						break;
		}
		
		
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		
		
		//Checklist
		checkList(driver);
		
		//Set the Response to thecurrent step
		uiSelect = new Select(driver.findElement(By.className("actionSelect")));
		
		try
		{
			uiSelect.selectByVisibleText(jsonOfCurrentTxn.get("Step Response").getAsString());
		}catch(Exception e)
		{
			uiSelect.selectByVisibleText("Accept");
		}
		//driver.findElement(By.className("accesskey"));
		driver.findElement(By.xpath("//*[@id=\"transactionSection\"]/table[2]/tbody/tr/td[3]/table/tbody/tr/td[3]/div/div/div/button")).click();
					
		//switch to inbox frame
		//Thread.sleep(500);
		driver.switchTo().defaultContent();
		webDriverWait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("Inbox V2.0"));
		//driver.switchTo().frame("Inbox V2.0");
	}
	
	public static boolean txnAvailabilityCheck(WebDriver driver,WebDriverWait webDriverWait,JsonObject dataJSONObject,Object[] dataMasterKeyArray,int dataLoopingIndex) throws InterruptedException
	{	
		boolean txnAvailabilityFlag = false;
		try{
		webDriverWait.until(ExpectedConditions.visibilityOf(driver.findElement(By.className("search-btn"))));
		}
		catch(Exception e)
		{
			System.out.println("frame switch failed");
		}
		FluentWait<WebDriver> fluentWait = new FluentWait<WebDriver>(driver);
		fluentWait.withTimeout(60, TimeUnit.SECONDS);
		fluentWait.pollingEvery(10, TimeUnit.SECONDS);
		//fluentWait.ignoring(NoSuchElementException.class);
		fluentWait.ignoring(TimeoutException.class);
		//fluentWait.ignoring(Exception.class);
	
		//Thread.sleep(20000);
		
		//driver.findElement(By.className("search-btn")).click();
		
		//Thread.sleep(1500);
		/*if(driver.findElements(By.className("task2")).isEmpty())	
		 txnAvailabilityFlag = false;*/
	
		Function<WebDriver, Boolean> function = new Function<WebDriver, Boolean>() {
		
			public Boolean apply(WebDriver driver) 
			{	
				driver.findElement(By.className("search-btn")).click();
				if(!driver.findElements(By.className("task2")).isEmpty())
					return true;
				else
					return false;
			}
		};
		
		try{
			txnAvailabilityFlag = fluentWait.until(function);	
		}
		catch(TimeoutException e)
		{
			System.out.println("Time out");
			txnAvailabilityFlag = false;
		}
		
		
		System.out.println("Transaction availability : "+txnAvailabilityFlag);
		
		return txnAvailabilityFlag;
	}

	public static void keyINValues(WebDriver driver, WebDriverWait webDriverWait, JsonObject jsonOfCurrentTxn)
	{
		boolean dummyFlag = false;
		String fieldLabel1 = null;
		String fieldLabel = null;
		String currentWebElementClassName;
		WebElement masterWebElement;
		List<WebElement> childWebElementList;
		Select uiSelect = null;
		String tempFieldLabel = null;
		StopWatch stopWatch = new StopWatch();

		String qwerty = getLastField(driver,webDriverWait).trim();
		//String qwerty = qwerty1.trim();
		System.out.println("Last field is <<<<<<<>>>>>>>> "+qwerty);
		//nextField :  for(;!isAlertPresent(driver);)
		nextField : for(;!qwerty.equalsIgnoreCase(tempFieldLabel);)
	     {
			//get the field name
			//fieldLabel1 = driver.findElement(By.xpath("//*[@id=\"transactionSection\"]/table[1]/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/div")).getText();
			stopWatch.start();
			do{
				try
				{
					fieldLabel1 = 	driver.findElement(By.className("fieldLbl")).getText();
					if(fieldLabel1.contains("*"))
						fieldLabel = fieldLabel1.substring(0, fieldLabel1.indexOf("*"));
					else
						fieldLabel= fieldLabel1;
					
					if(stopWatch.getTime()>=7000)
					{
							System.out.println("<<<<<<<<ERROR OCCURED>>>>>>>>>>");
					}
					
				}
				catch(Exception e)
				{
					dummyFlag = true;
				}
				if(dummyFlag)break;
				
			}while(fieldLabel.equalsIgnoreCase(tempFieldLabel));
			
			if(dummyFlag)break;
			stopWatch.stop();
			stopWatch.reset();
			
			System.out.println("Field Label : "+fieldLabel);
			tempFieldLabel = fieldLabel;
			
			//fieldLbl
			//WebElement temp = driver.findElement(By.xpath("//*[@id=\"transactionSection\"]/table[1]/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td"));
			WebElement temp = driver.findElement(By.className("fieldLbl"));
			List<WebElement> temp1 = temp.findElements(By.tagName("div"));
			if(temp1.size()>2)
			{	
				if(jsonOfCurrentTxn.has(fieldLabel))
				{
					List<WebElement> radioElements = driver.findElements(By.className("gwt-RadioButton"));
					for(int radioElementsIndex=0;radioElementsIndex<radioElements.size();radioElementsIndex++)
					{
						String radioElementText = radioElements.get(radioElementsIndex).getText();
						//System.out.println("Radion text %%%% " +radioElementText);
							
						if(radioElementText!=null && radioElementText.equalsIgnoreCase(jsonOfCurrentTxn.get(fieldLabel).getAsString()))
						{
							radioElements.get(radioElementsIndex).click();
							radioElements.get(radioElementsIndex).sendKeys(Keys.ENTER);
							break;
						}
					}	
				}
				else
				{
					try {
						Thread.sleep(700);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					WebElement ele = driver.findElement(By.xpath("//*[@id=\"transactionSection\"]/table[1]/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/div"));
					
					ele.sendKeys(Keys.ENTER);
				}		
			}
			
			else 
			
			{
				masterWebElement = driver.findElement(By.className("transactionTypeSelectCont"));
		     childWebElementList = masterWebElement.findElements(By.xpath(".//*"));
		     
		     for(WebElement currentWebElement : childWebElementList)
			    {
		    	 
		    	 	boolean f = false;
		    	 	if(jsonOfCurrentTxn.has(fieldLabel))
		    	 	{
		    	 		 currentWebElementClassName = currentWebElement.getAttribute("class");
		    	 		 //System.out.println("Current class name : "+currentWebElementClassName);
		    	 		 
		    	 		 switch (currentWebElementClassName) 
		    	 		 {
		    	 		 
		    	 		 	case "selMed": uiSelect = new Select(currentWebElement);
		    						   		uiSelect.selectByVisibleText(jsonOfCurrentTxn.get(fieldLabel).getAsString());
		    						   break;
		    						   
		    	 		 	case "inputMed": if(currentWebElement.getAttribute("value").isEmpty())
		    	 		 					 currentWebElement.sendKeys(jsonOfCurrentTxn.get(fieldLabel).getAsString());			   
		    						   break;
		    			
		    	 		 	case "inputMed inputMed-readonly readOnlyInput" : break;//non editable field
		    	 		 	
		    	 		 	default:	
		    	 		 		f = true;
		    	 		 	List<WebElement> radioElements = driver.findElements(By.className("gwt-RadioButton"));
							for(int radioElementsIndex=0;radioElementsIndex<radioElements.size();radioElementsIndex++)
							{
								String radioElementText = radioElements.get(radioElementsIndex).getText();
								if(radioElementText.equalsIgnoreCase(jsonOfCurrentTxn.get(fieldLabel).getAsString()))
									{
									radioElements.get(radioElementsIndex).click();
									radioElements.get(radioElementsIndex).sendKeys(Keys.ENTER);
									break;
									}
							}	
		    	 		 				break;
						}
		    	 	}
		    	 	
		    	 	if(!f)
		    	 	{
		    	 		if(fieldLabel.equalsIgnoreCase("Debit Contact Details"))
				    		driver.findElement(By.className("cancelBtn")).click();
		    	 		
			    		else
			    			
			    			currentWebElement.sendKeys(Keys.ENTER);
		    	 	}
		    	 	
		    	 	/*if(fieldLabel.equalsIgnoreCase("Debit Ac No"))
		    	 	{	try {
							Thread.sleep(1500);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}	
		    	 	}*/
		    	 	
		    	 	/*try {
						Thread.sleep(700);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}*/
			    	continue nextField;}
			    }
			   }
	
		
		
	}
	
	public static String getLastField(WebDriver driver, WebDriverWait webDriverWait)
	{
		String tempLastField = null;
		String lastField = null;
		try{
		webDriverWait.until((ExpectedConditions.elementToBeClickable(driver.findElement(By.id("data-table")))));
		}catch(TimeoutException e)
		{
			System.out.println("Frame not yet loaded !!!");
		}
		WebElement tableName = driver.findElement(By.id("data-table"));
		
		List<WebElement> alltrs = tableName.findElements(By.tagName("tr"));
		
		for(int i=alltrs.size()-1;i>=0;i--)
		{
			String attr = alltrs.get(i).getAttribute("aria-hidden");
			if(!attr.equalsIgnoreCase("true"))
			{
				tempLastField = alltrs.get(i).findElement(By.tagName("td")).getText();
				if(tempLastField.contains("*"))
					lastField = tempLastField.substring(0, tempLastField.lastIndexOf("*"));
				else if(tempLastField.contains("x"))
						lastField = tempLastField.substring(0, tempLastField.lastIndexOf("x"));
				else
					lastField = tempLastField;
				break;
			}
		}
		return lastField;
	}
	
	
	
	
	
	
	
}